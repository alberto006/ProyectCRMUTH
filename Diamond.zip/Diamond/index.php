<html>
    <head>
        <title>Maquila Diamond</title>
        <link type="text/css" href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>
    <body>
        <div id="root"></div>

        <script type="text/javascript" src="assets/js/jquery.js"></script>
        <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

        <?php
        //Validacion de session y carga de vista inicial        
        session_start();
        if(isset( $_SESSION['usuario']) ){
            
            if($_SESSION['TipoUsuario']=="Empleado"){
                ?>
                <script type="text/javascript">
                    $(document).ready(function(){
                        $("#root").load("frontend/views/Sistema/Empleado.php");
                    });       
                </script>
                <?php    
            }else{
                ?>
                <script type="text/javascript">
                    $(document).ready(function(){
                        $("#root").load("frontend/views/Sistema/Cliente.php");
                    });       
                </script>
                <?php    
            }

        }else{
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    $("#root").load("frontend/views/Sistema/Invitado.php");
                });       
            </script>
            <?php
        }
        ?>

    </body>
</html>

