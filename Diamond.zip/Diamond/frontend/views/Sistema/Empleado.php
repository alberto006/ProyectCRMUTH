<?php
session_start();
if(!isset($_SESSION['usuario'])){
    ?>
    <script type="text/javascript">
        $("#root").load("frontend/views/Sistema/Login.php");
    </script>
    <?php
}
?>
<div>

    <nav class="navbar navbar-expand-lg navbar-light bg-dark text-white">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand text-white" href="#" ><span><img src="assets/img/logo.png" width="40" height="40"></span>Diamond</a>

          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <button class="btn btn-outline-info my-2 my-sm-0 mr-1" type="button" id="btnLogin">Ordenes</button>
            <button class="btn btn-outline-info my-2 my-sm-0" type="button" id="btnLogin">Perfil</button>
          </ul>          
            <button class="btn btn-outline-danger my-2 my-sm-0" type="button" id="btnSalir">Salir</button>          
        </div>
      </nav>
        
        <!--- Barra de navegacion de inicio ---->       
        
        <!--- Contenido principal de la pagina --->
        <div class="container mt-4" id="MainContainer">
            <h4>Bienvenido <?= $_SESSION['usuario'] ?></h4>
                  
        </div>


        <!--- Modal --->
        <div class="modal fade modal-danger" id="ModalCerrarSession" tabindex="-1" role="dialog" aria-labelledby="ModalCerrarSessionLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header bg-danger text-white text-center">
                <h5 class="modal-title " id="ModalCerrarSessionLabel">Esta seguro que desea salir?</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <button class="btn btn-danger" id="btnDestroySession">Salir</button>
                <button class="btn btn-info" class="btnCancelar">Cancelar</button>
            </div>            
            </div>
        </div>
        </div>
        <!--- Modal --->
        

</div>

<script type="text/javascript">
    $("#btnSalir").click(function(){
        $("#ModalCerrarSession").modal('show');
    })
    $("#btnDestroySession").click(function(){
        var request = "DestroySession";
        $.post('backend/Controller/SessionController.php',{
            request:request
        }).done(function(response){
            if(response.status == "success"){
                window.location.href = './';
            }else{
                alert("No se pudo finalizar la sesion");
                console.log(response)
            }
        }).fail(function(error){
            alert("Error en el programa: No se pudo finalizar la sesion");
            console.log(response)
        })
    })

    $(".btnCancelar").click(function(){
        $("#ModalCerrarSession").modal('hide');
    });
</script>