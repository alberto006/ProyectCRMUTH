<style>
    .text-gris{
        color:rgba(212,212,212);
    }

</style>

<div>

<nav class="navbar navbar-expand-lg navbar-light bg-dark text-white">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand text-white" href="#" ><span><img src="assets/img/logo.png" width="40" height="40"></span>Diamond</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          </ul>          
            <button class="btn btn-outline-primary my-2 my-sm-0" type="button" id="btnInicio">Inicio</button>          
        </div>
      </nav>
        
        <!--- Barra de navegacion de inicio ---->       
        
        <!--- Contenido principal de la pagina --->
        <div class="container mt-4" id="MainContainer">
            
            <div class="row">
                <div class="col-md-6 align-middle">
                    <div class="jumbotron text-center text-gris" style="background-color: white;">
                        <h1>Diamond</h1>
                        <img style="width: 80%;heigth:auto;" src="assets/img/logo.png" >
                        <h3>Maquila Textil</h3>
                    </div>

                </div>


                <div class="col-md-6 align-middle">

                    <div class="card" style="margin-top:auto;margin-botton:auto;">
                        <div class="card-header text-primary" style="background-color: white;">
                            <h3>Iniciar Sesion</h3>
                        </div>
                        <div class="card-body">

                            <form id="FormLogin">
                                <input type="hidden" value="InitSession" name="request">
                                <div class="row my-auto">
                                    <div class="col-md-12 m-2">
                                        <label>Usuario</label>                                
                                        <input type="text" class="form-control form-control-sm" placeholder="Usuario" name="usuario" require> 
                                    </div>
                                
                                
                                    <div class="col-md-12 m-2">
                                        <label>Clave</label>
                                        <input type="password" class="form-control form-control-sm" placeholder="Clave de acceso" name="clave" require> 
                                    </div>
                                
                                    <div class="col-md-12 text-center mt-4">
                                        <button class="btn btn-success float-left" type="submit">Entrar</button>
                                    </div>
                                </div>
                                
                            </form>

                        </div>
                        <div class="card-footer text-gris">
                            <a href="#" onClick="$('#root').load('frontend/views/Sistema/Registro.php')">Registrarse como cliente</a>
                        </div>
                    </div>


                </div>
            </div>
            
        </div>

        

</div>


<script type="text/javascript">

    $("#btnInicio").click(function(){
        $("#root").load("frontend/views/Sistema/Invitado.php");
    });

    $("#FormLogin").on('submit',function(e){
        e.preventDefault();

        $.ajax({
            url:'backend/Controller/SessionController.php',
            method:'POST',
            data:new FormData(this),
            contentType:false,
            processData:false,
            success:function(response){
                if(response.status == "success"){
                    if(response.data == "Empleado"){
                        $("#root").load("frontend/views/Sistema/Empleado.php");
                    }else{
                        $("#root").load("frontend/views/Sistema/Cliente.php");
                    }
                }else{
                    alert("Error al iniciar session: "+response.message);
                    console.log(response);
                }
            },
            fail:function(error){
                alert("Error en el programa");
                 console.log(error);
            }


        })

    })


</script>