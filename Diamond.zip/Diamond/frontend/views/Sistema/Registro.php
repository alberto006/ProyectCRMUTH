<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Models/Clientes.php';

$Clientes = new Clientes;

$TiposClientes = $Clientes->GetTipoClientes();
$Ciudades = $Clientes->GetCiudades();
?>

<style>
    .text-gris{
        color:rgba(212,212,212);
    }
</style>

<div>

<nav class="navbar navbar-expand-lg navbar-light bg-dark text-white">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand text-white" href="#" ><span><img src="assets/img/logo.png" width="40" height="40"></span>Diamond</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          </ul>          
            <button class="btn btn-outline-primary my-2 my-sm-0" type="button" id="btnInicio">Inicio</button>          
        </div>
      </nav>
        
        <!--- Barra de navegacion de inicio ---->       
        
        <!--- Contenido principal de la pagina --->
        <div class="container mt-4" id="MainContainer">
            
            <div class="row">
                <div class="col-md-6">
                    <div class="jumbotron text-center text-gris" style="background-color: white;">
                        <h1>Diamond</h1>
                        <img style="width: 80%;heigth:auto;" src="assets/img/logo.png" >
                        <h3>Maquila Textil</h3>
                    </div>

                </div>


                <div class="col-md-6">

                    <div class="card" style="margin-top:auto;margin-botton:auto;">
                        <div class="card-header text-primary" style="background-color: white;">
                            <h3>Registro de Cliente</h3>
                        </div>
                        <div class="card-body">

                            <form id="FormRegistro">
                                <input type="hidden" value="RegistroCliente" name="request">
                                <div class="row">
                                    <div class="col-md-12 m-2">
                                        <label>Tipo de Cliente</label>                                
                                        <select class="form-control" name="ID_TipoCliente" require>
                                            <option></option>
                                            <?php
                                                foreach($TiposClientes[2] as $key => $value){
                                                    ?>
                                                    <option value="<?= $value['ID_TipoCliente'] ?>"><?= $value['TipoCliente'] ?></option>
                                                    <?php
                                                }
                                            ?>

                                        </select>
                                    </div>
                                
                                
                                    <div class="col-md-12 m-2">
                                        <label>Nombre de cliente</label>
                                        <input type="text" class="form-control " placeholder="Nombre cliente" name="NombreCliente" require> 
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Clave de acceso</label>
                                        <input type="password" class="form-control" placeholder="Clave" name="clave" id="clave1" require> 
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Verificar Clave</label>
                                        <input type="password" class="form-control " placeholder="Verificar" name="ClaveVerificar" id="clave2" require> 
                                    </div>

                                    

                                    <div class="col-md-12 m-2">
                                        <label>RTN o Identidad</label>
                                        <input type="text" class="form-control " placeholder="Documento" name="RTN" require> 
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Telefono</label>
                                        <input type="text" class="form-control " placeholder="Telefono contacto" name="TelefonoContacto" require> 
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Correo Electronico</label>
                                        <input type="email" class="form-control " placeholder="Correo Electronico" name="CorreoElectronico" require> 
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Direccion</label>
                                        <textarea class="form-control" name="Direccion"></textarea>
                                    </div>

                                    <div class="col-md-12 m-2">
                                        <label>Ciudad</label>                                
                                        <select class="form-control" name="ID_Ciudad" require>
                                            <option></option>
                                            <?php
                                                foreach($Ciudades[2] as $key => $value){
                                                    ?>
                                                    <option value="<?= $value['ID_Ciudad'] ?>"><?= $value['Ciudad'] ?></option>
                                                    <?php
                                                }
                                            ?>

                                        </select>
                                    </div>


                                
                                
                                
                                    <div class="col-md-12 text-center mt-4">
                                        <button class="btn btn-success float-left" type="submit">Entrar</button>
                                    </div>
                                </div>
                                
                            </form>

                        </div>
                        <div class="card-footer text-gris">
                            <a href="#" onClick="$('#root').load('frontend/views/Sistema/Login.php')">Entrar como usuario</a>
                        </div>
                    </div>


                </div>
            </div>
            
        </div>

        

</div>


<script type="text/javascript">

    $("#btnInicio").click(function(){
        $("#root").load("frontend/views/Sistema/Invitado.php");
    });

    $("#FormRegistro").on('submit',function(e){
        e.preventDefault();
        var clave1 = $("#clave1").val();
        var clave2 = $("#clave2").val();

        if(clave1 != clave2){
            alert("Las claves no coinciden, por favor vuelva a intentarlo");
        }else{
            $.ajax({
                url:'backend/Controller/SessionController.php',
                method:'POST',
                data:new FormData(this),
                contentType:false,
                processData:false,
                success:function(response){
                    if(response.status == "success"){
                        $("#root").load("frontend/views/Sistema/Cliente.php");
                    }else{
                        alert("Error al iniciar session: "+response.message);
                        console.log(response);
                    }
                },
                fail:function(error){
                    alert("Error en el programa");
                    console.log(error);
                }


            })
        }
        

    })


</script>