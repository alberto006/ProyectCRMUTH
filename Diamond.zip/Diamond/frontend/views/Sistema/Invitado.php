<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Models/Productos.php';
$Productos = new Productos;
$ListaProductos = $Productos->Listar();
?>

<div>

<nav class="navbar navbar-expand-lg navbar-light bg-dark text-white">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
            <a class="navbar-brand text-white" href="#" ><span><img src="assets/img/logo.png" width="40" height="40"></span>Diamond</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          </ul>          
            <button class="btn btn-outline-success my-2 my-sm-0" type="button" id="btnLogin">Entrar</button>          
        </div>
      </nav>
        
        <!--- Barra de navegacion de inicio ---->       
        
        <!--- Contenido principal de la pagina --->
        <div class="container mt-4" id="MainContainer">
            
            <h1>Catalogo de productos</h1>
            
            <br>
            
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                  <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Camisas</a>
                  <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Pantalones</a>
                  <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Interiores</a>
                </div>
              </nav>
              <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                      
                      <div class="row pb-4 pt-4" id="CatalogoCamisas">
                          <div class="col-lg-12 mt-4">
                              <h2>Camisas</h2>
                          </div>     
                          
                          
                      </div>
                      
                      
                  </div>
                  <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                  <div class="row pb-4 pt-4" id="CatalogoPantalones">
                          <div class="col-lg-12 mt-4">
                              <h2>Pantalones</h2>
                          </div>     
                          
                          
                      </div>
                  </div>
                  <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                  <div class="row pb-4 pt-4" id="CatalogoInteriores">
                          <div class="col-lg-12 mt-4">
                              <h2>Interiores</h2>
                          </div>     
                          
                          
                      </div>
                  </div>
              </div>
            
        </div>

        

</div>


<script type="text/javascript">

    function number_format(val, decimals){     
        val = parseFloat(val);                
        return val.toFixed(decimals);
    }
    
    var ListaProductos = <?= json_encode($ListaProductos[2]) ?>;
    console.log(ListaProductos);
    var Camisas = "";
    var Pantalones = "";
    var Interiores = "";

    for(var i = 0;i<ListaProductos.length;i++){
        switch(ListaProductos[i].Categoria){
            case 'CAMISAS':
            Camisas = Camisas + '<div class="col-md-3 ">'
                              +'<div class="card text-center" style="width: 18rem;">'                                  
                                    +'<img style="width:200px;height:250px;" src="'+ListaProductos[i].RutaImagen+'" class="card-img-top mx-auto">'
                                  +'<div class="card-body">'                                        
                                    +'<p class=" font-weight-bolder">'+ListaProductos[i].NombreProducto+'</p>' 
                                    +'<p class="font-weight-light small">'+ListaProductos[i].Descipcion+'</p>'
                                  +'</div>'
                                  +'<div class="footer">'                                      
                                      
                                      +'<div class="alert font-weight-bolder mx-4 alert-info">L. '+number_format(ListaProductos[i].PrecioVenta,2) +'</div>'
                                  +'</div>'                                  
                              +'</div>'
                          +'</div>';
            break;
            case 'PANTALONES':
            Pantalones = Pantalones + '<div class="col-md-3 ">'
                              +'<div class="card text-center" style="width: 18rem;">'                                  
                                    +'<img style="width:200px;height:250px;" src="'+ListaProductos[i].RutaImagen+'" class="card-img-top mx-auto">'
                                  +'<div class="card-body">'                                        
                                    +'<p class=" font-weight-bolder">'+ListaProductos[i].NombreProducto+'</p>' 
                                    +'<p class="font-weight-light small">'+ListaProductos[i].Descipcion+'</p>'
                                  +'</div>'
                                  +'<div class="footer">'                                      
                                      
                                      +'<div class="alert font-weight-bolder mx-4 alert-info">L. '+number_format(ListaProductos[i].PrecioVenta,2) +'</div>'
                                  +'</div>'                                  
                              +'</div>'
                          +'</div>';
            break;
            case 'INTERIORES':
            Interiores = Interiores + '<div class="col-md-3 ">'
                              +'<div class="card text-center" style="width: 18rem;">'                                  
                                    +'<img style="width:200px;height:250px;" src="'+ListaProductos[i].RutaImagen+'" class="card-img-top mx-auto">'
                                  +'<div class="card-body">'                                        
                                    +'<p class=" font-weight-bolder">'+ListaProductos[i].NombreProducto+'</p>' 
                                    +'<p class="font-weight-light small">'+ListaProductos[i].Descipcion+'</p>'
                                  +'</div>'
                                  +'<div class="footer">'                                      
                                      
                                      +'<div class="alert font-weight-bolder mx-4 alert-info">L. '+number_format(ListaProductos[i].PrecioVenta,2) +'</div>'
                                  +'</div>'                                  
                              +'</div>'
                          +'</div>';
            break;
        }
        

        
    }
    $("#CatalogoCamisas").html(Camisas);
    $("#CatalogoPantalones").html(Pantalones);
    $("#CatalogoInteriores").html(Interiores);


    $("#btnLogin").click(function(){
        $("#root").load("frontend/views/Sistema/Login.php");
    })
</script>