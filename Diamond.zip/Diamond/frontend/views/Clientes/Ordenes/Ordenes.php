<?php
session_start();
$Modulo = "Ordenes";
$permisos = $_SESSION['permisos'];
include_once $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Models/Clientes.php';
$Clientes = new Clientes;
$ListaOrdenes = $Clientes->GetOrdenes($_SESSION['usuario']);
$FormasPago = $Clientes->GetFormaPagos();

if(in_array($Modulo,$permisos)){    
    ?>
    <!--Opciones -->
    <div class="row mb-4" >
        <?php 
            if($permisos['C']==1){
                ?>               
                    <button class="btn btn-outline-success my-2 my-sm-0" data-toggle="modal" data-target="#ModalNuevaOrden" >Nueva Orden</button>
                    <!-- Modal -->
                    <div class="modal fade" id="ModalNuevaOrden" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="ModalNuevaOrdenLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                            <div class="modal-header bg-success text-white">
                                <h5 class="modal-title" id="ModalNuevaOrdenLabel">Crear Nueva Orden de Compra</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                
                                <!-- Seleccion de productos -->
                                <div class="row">
                                    <div class="col-md-3">                                    
                                        
                                        <label class="text-success">Categorias de productos</label>
                                        <select class="form-control" id="selectCategorias">
                                            <option></option>
                                            <option value="1">Camisas</option>
                                            <option value="2">Pantalones</option>
                                            <option value="3">Interiores</option>
                                        </select>              


                                        <label class="text-success">Forma de Pago</label>                                    
                                        <select class="form-control" id="selectFormaPago">
                                            <option></option>
                                            <?php
                                                foreach($FormasPago[2] as $key => $val){
                                                    ?>
                                                        <option value="<?= $val['ID_FormaPago'] ?>"><?= $val['FormaPago'] ?></option>
                                                    <?php
                                                }
                                            ?>
                                        </select>
                                        
                                    </div>                                    
                                    

                                    <div class="col-md-9 p-3">                                    
                                    <div style="overflow-y: scroll;max-height:270px;height:270px;">
                                            <div class="row mt-2"  id="CatalogoProductos">
                                                <div class="col-md-12">
                                                    <div class="alert alert-info">Seleccione una categoria de productos</div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                                
                                </div>
                                <!-- Seleccion de productos -->

                                <!-- Detalle de orden con subtotales -->
                                <form id="FormOrden">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5>Detalle de Orden</h5>
                                                </div>
                                                <div class="card-body">                                                    
                                                    <div class="row">
                                                       <div class="col-md-12">
                                                           <div class="table-responsive-sm" style="overflow-y: scroll;max-height:270px;">
                                                                <table class="table table-condensed table-hover table-bordered small text-center">
                                                                    <thead class="bg-dark text-white">
                                                                        <tr>
                                                                            <th>Producto</th>                                                                       
                                                                            <th>Unidades Paquete</th>
                                                                            <th>Precio Unitario</th>
                                                                            <th>Imagen</th>
                                                                            <th>Cantidad</th>
                                                                            <th>Opciones</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="tbodyProductos"></tbody>
                                                                </table>
                                                           </div>
                                                       </div>
                                                    </div>                                                    
                                                </div>
                                                <div class="card-footer">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <label>Subtotal</label>
                                                            <input 
                                                                type="number"
                                                                step="any" 
                                                                class="form-control form-control-sm" 
                                                                id="Subtotal"
                                                                readonly
                                                                style="
                                                                    background-color: white;
                                                                    font-size:1.3em;
                                                                    color:blue
                                                                    "
                                                            >                                                           
                                                        </div>

                                                        <div class="col-md-4">
                                                            <label>ISV</label>
                                                            <input 
                                                                type="number"
                                                                step="any" 
                                                                class="form-control form-control-sm" 
                                                                id="ISV"
                                                                readonly
                                                                style="
                                                                    background-color: white;
                                                                    font-size:1.3em;
                                                                    color:blue
                                                                    "
                                                            >                                                           
                                                        </div>

                                                        <div class="col-md-4">
                                                            <label>Total a Pagar</label>
                                                            <input 
                                                                type="number"
                                                                step="any" 
                                                                class="form-control form-control-sm" 
                                                                id="TotalPago"
                                                                readonly
                                                                style="
                                                                    background-color: white;
                                                                    font-size:1.3em;
                                                                    color:blue
                                                                    "

                                                            >                                                           
                                                        </div>

                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </form>
                                <!-- Detalle de orden con subtotales -->
                            </div>


                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary">Procesar orden</button>
                            </div>
                            </div>
                        </div>
                    </div>



                <?php
            }
        ?>        
    </div>

    <?php
    if(sizeof($ListaOrdenes[2])>=1){
        ?>
            <!--Tabla de registros -->
            <div class="row">
                <table class="table table-hover table-stiped table-condensed table-bordered text-center small table-dark">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>N° Orden</th>
                            <th>Forma Pago</th>
                            <th>Fecha orden</th>
                            <th>Estado</th>
                            <th>Observaciones</th>
                            <th>Opciones</th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php
    }else{
        ?>
        <div class="alert alert-warning">
            <h4>No se ha realizado ordenes aun!</h4>
        </div>
        <?php
    }

}else{
    ?>
    <div class="alert alert-danger">No tiene permiso para este modulo!<br>Contacte el administrador del sistema</div>

    <?php
}

?>



<script type="text/javascript">
    function number_format(val, decimals){     
        val = parseFloat(val);                
        return val.toFixed(decimals);
    }

    $("#selectCategorias").on('change',function(){
        var categoria = $("#selectCategorias").val();
        var request = "GetProductosByCategoria";
        if(categoria != ""){
            $.post('backend/Controller/ProductosController.php',{
                request:request,
                categoria:categoria
            }).done(function(response){

                if(response.status == 'success'){                                        
                    $("#CatalogoProductos").html("");
                    var lista = response.data;                    
                    var Productos = "";

                    if(lista.length>=1){
                        for(var i = 0; i < lista.length; i++ ){
                            Productos = Productos + '<div class="col-md-3 border m-1 text-center">'
                                                +'<img src="'+lista[i].RutaImagen+'" style="width:100px;height:auto">'
                                                +'<p class="small">'+lista[i].NombreProducto+' ('+lista[i].UnidadesProducto+')</p>'
                                                +'<p><span class="badge badge-info">L. '+number_format(lista[i].PrecioVenta,2)+'</span></p>'
                                                +'<p><button class="btn btn-outline-success btn-sm" '
                                                    +'onClick="AgregarProducto('+lista[i].ID_Producto+',\''+lista[i].NombreProducto+'\','+lista[i].UnidadesProducto+','+lista[i].PrecioVenta+',\''+lista[i].RutaImagen+'\')">Agregar'
                                                    +'</button></p>'
                                            +'</div>'
                                        
                        }
                    }else{
                        Productos = '<div class="col-md-12"><div class="alert alert-warning">No hay productos en esta categoria</div></div>';
                    }                    

                    $("#CatalogoProductos").html(Productos);

                }

            }).fail(function(error){
                alert('Error al obtener los datos')
                console.log(error);
            })
        }
    })
</script>

<script type="text/javascript">
    //Variables Globales
    //objeto para Detalle de orden    
    var OrdenDetalle = [];
    var subtotal = 0;
    var isv = 0;
    var totalpago = 0;

    //---------------------------------------------------------------------------------------------------//
    //Funcion para agregar un producto a la lista
    function AgregarProducto(id,nombre,unidades,precio,imagen){        
        if(OrdenDetalle.length === 0){

            OrdenDetalle.push({"ID_Producto":id,"Cantidad":1,"PrecioUnitario":precio});

            subtotal = number_format(precio,2);
            isv = number_format(subtotal*0.15,2);
            totalpago = number_format(parseFloat(subtotal)+parseFloat(isv),2);

            $("#Subtotal").val(subtotal);
            $("#ISV").val(isv);
            $("#TotalPago").val(totalpago);

            var row ='<tr class="font-weight-bolder" style="font-size:1.3em" id="Producto-'+id+'">'
                +'<td class="align-middle" id="NombreProducto-'+id+'">'+nombre+'</td>'
                +'<td class="align-middle" id="UnidadesProducto-'+id+'">'+unidades+'</td>'
                +'<td class="align-middle" id="PrecioProducto-'+id+'">'+precio+'</td>'
                +'<td>'
                    +'<img src='+imagen+' class="rounded mx-auto d-block" style="width:70px;heigth:auto">'
                +'</td>'
                +'<td class="align-middle" id="CantidadProducto-'+id+'">1</td>'
                +'<td class="align-middle">'
                    +'<button class="btn btn-info btn-sm" type="button" onClick="RestarProducto('+id+')"><span class="fa fa-minus" ></span></button>'
                    +'<button class="btn btn-danger btn-sm" type="button" onClick="RemoverProducto('+id+')"><span class="fa fa-ban"></span></button>'
                +'</td>'
            +'</tr>';
    
            $("#tbodyProductos").append(row);


        }else{
            if(OrdenDetalle.find(Producto => Producto.ID_Producto === id)){  
                try{
                    OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad = OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad +1;                 
                    $("#CantidadProducto-"+id).html(OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad)
                    subtotal = parseFloat(subtotal) + parseFloat(precio);
                    isv = number_format(subtotal*0.15,2);
                    totalpago = number_format(parseFloat(subtotal)+parseFloat(isv),2);
                    $("#Subtotal").val(subtotal);
                    $("#ISV").val(isv);
                    $("#TotalPago").val(totalpago);
                }catch(error){
                    alert('Error');
                    console.log(error);
                }              
                

            }else{
                OrdenDetalle.push({"ID_Producto":id,"Cantidad":1,"PrecioUnitario":precio});

                try{
                    subtotal = parseFloat(subtotal) + parseFloat(precio);
                    isv = number_format(subtotal*0.15,2);
                    totalpago = number_format(parseFloat(subtotal)+parseFloat(isv),2);
                    $("#Subtotal").val(subtotal);
                    $("#ISV").val(isv);
                    $("#TotalPago").val(totalpago);

                    var row ='<tr class="font-weight-bolder" style="font-size:1.3em" id="Producto-'+id+'">'
                    +'<td class="align-middle" id="NombreProducto-'+id+'">'+nombre+'</td>'
                    +'<td class="align-middle" id="UnidadesProducto-'+id+'">'+unidades+'</td>'
                    +'<td class="align-middle" id="PrecioProducto-'+id+'">'+precio+'</td>'
                    +'<td>'
                        +'<img src='+imagen+' class="rounded mx-auto d-block" style="width:70px;heigth:auto">'
                    +'</td>'
                    +'<td class="align-middle" id="CantidadProducto-'+id+'">1</td>'
                    +'<td class="align-middle">'
                        +'<button class="btn btn-info btn-sm" type="button" onClick="RestarProducto('+id+')"><span class="fa fa-minus"></span></button>'
                        +'<button class="btn btn-danger btn-sm" type="button" onClick="RemoverProducto('+id+')"><span class="fa fa-ban"></span></button>'
                    +'</td>'
                +'</tr>';
        
                $("#tbodyProductos").append(row);
                }catch(error){
                    alert('Error');
                    console.log(error);
                } 
            }        
        }
     
    
    }
    //---------------------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------------------//
    //Funcion para restar un producto de la lista seleccionada
    function RestarProducto(id){        
        CantidadActual = OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad;        
        PrecioUnitario = OrdenDetalle.find(Producto => Producto.ID_Producto === id).PrecioUnitario;        
        OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad = CantidadActual-1;
        subtotal =number_format( parseFloat(subtotal) - parseFloat(PrecioUnitario),2);
        isv =number_format( parseFloat(isv) - (parseFloat(PrecioUnitario) * 0.15), 2)
        totalpago = number_format( parseFloat(totalpago) - ( (PrecioUnitario) + (parseFloat(PrecioUnitario) * 0.15) ),2)

        $("#Subtotal").val(subtotal);
        $("#ISV").val(isv);
        $("#TotalPago").val(totalpago);

        if(OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad === 0){
            var index = OrdenDetalle.findIndex(Producto => Producto.ID_Producto === id);
            
            var tempObject = [];
            for(var i = 0; i<OrdenDetalle.length;i++){
                if(i!=index){
                    tempObject.push(OrdenDetalle[i]);
                }                    
            }

            OrdenDetalle = tempObject;

            $("#Producto-"+id).remove();
        }else{
            $("#CantidadProducto-"+id).html(OrdenDetalle.find(Producto => Producto.ID_Producto === id).Cantidad)
        }

    }
    //---------------------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------------------//
    //Funcion para remover un producto de la lista
    function RemoverProducto(id){
        var index = OrdenDetalle.findIndex(Producto => Producto.ID_Producto === id);

        var ProductoPrecio = OrdenDetalle[index].PrecioUnitario;
        var ProductoCantidad = OrdenDetalle[index].Cantidad;
        var ProductoSubtotal = ProductoPrecio * ProductoCantidad;

        subtotal = number_format( (subtotal - ProductoSubtotal) , 2)
        isv = number_format( (subtotal*0.15) ,2)
        totalpago = number_format ( (subtotal) + isv ,2)

        $("#Subtotal").val(subtotal);
        $("#ISV").val(isv);
        $("#TotalPago").val(totalpago);


        if(index>=0){
            var tempObject = [];
            for(var i = 0; i<OrdenDetalle.length;i++){
                if(i!=index){
                    tempObject.push(OrdenDetalle[i]);
                }                    
            }
            OrdenDetalle = tempObject;

            $("#Producto-"+id).remove();
        }
    }
    //---------------------------------------------------------------------------------------------------//

    console.log(<?= json_encode($_SESSION) ?>)
</script>