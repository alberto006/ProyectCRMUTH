<?php
class Db{
    
    //--------------------------------------------------------------------------------//
    protected static function Conexion(){
        $dsn= 'sqlsrv:server=localhost;Database=Maquila;';
        $dbusername="sa";
        $dbpassword='L0c@l2020';		
        $conexion = new PDO($dsn,$dbusername,$dbpassword);
        $conexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        return $conexion;
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    protected static function SP_Crear($Entidad,$Data){
        if(is_array($Data)){
            //Construccion del query para ejecutar el procedimiento almacenado
            $query = "EXEC ".$Entidad."_CREAR";
            for($i=1;$i<=sizeof($Data);$i++){
                if($i==1){
                    $query .= " ?";
                }else{
                    $query .= " ,?";
                }                
            }
            $query .= ",?";
            try{
                $conexion = Self::Conexion();
                $sentencia = $conexion->prepare($query);                
                for($i=1;$i<=sizeof($Data);$i++){
                    $sentencia->bindParam($i,$Data[$i-1]);                    
                }
                $sentencia->bindParam(sizeof($Data)+1,$id,PDO::PARAM_INT|PDO::PARAM_INPUT_OUTPUT,PDO::SQLSRV_PARAM_OUT_DEFAULT_SIZE);
                if($sentencia->execute()){ 
                    if($id != null){
                        $informacion = Self::SP_Leer($Entidad,$id);                        

                        return [TRUE,"Datos guardados",$informacion[2]];
                    }else{
                        return [FALSE,"Error al guardar los datos",$sentencia->errorCode()];
                    }
                }else{
                    return [FALSE,"Error al guardar los datos",$sentencia->errorCode()];    
                }
            }catch(PDOException $e){
                return [FALSE,"Error en el programa",$e->getMessage(),$query];
            }
        }else{
            return [FALSE,"Error en los datos enviados, el programa debe recibir una arreglo (SP_CREAR)",null];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    protected static function SP_Leer($Entidad,$id){
        $query = "EXEC ".$Entidad."_LEER ?";
        try{
            $conexion=Self::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$id);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    //Metodo para ejecutar un Procedimiento almacenado para actualizar datos
    protected static function SP_Actualizar($Entidad,$Data){
        if(is_array($Data)){
            //Construccion del query para ejecutar el procedimiento almacenado
            $query = "EXEC ".$Entidad."_ACTUALIZAR";
            for($i=1;$i<=sizeof($Data);$i++){
                if($i==1){
                    $query .= " ?";
                }else{
                    $query .= " ,?";
                }                
            }          
            try{
                $conexion = Self::Conexion();
                $sentencia = $conexion->prepare($query);
                for($i=1;$i<=sizeof($Data);$i++){
                    $sentencia->bindParam($i,$Data[$i-1]);
                }                
                if($sentencia->execute()){ 
                    
                    $datos = Self::SP_Leer($Entidad,$Data[0]);
                    return [TRUE,"Datos actualizados",$datos[2]];
                }else{
                    return [FALSE,"Error al actualizar los datos",$sentencia->errorCode()];    
                }
            }catch(PDOException $e){
                return [FALSE,"Error en el programa",$e->getMessage()];
            }

        }else{
            return [FALSE,"Error en los datos enviados, el programa debe recibir una arreglo",null];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    protected static function SP_Eliminar($Entidad,$id){
        $query = "EXEC ".$Entidad."_ELIMINAR ?";
        try{
            $conexion = Self::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$id);
            if($sentencia->execute()){
                return [TRUE,"Se elimino el registro correctamente",null];
            }else{
                return [FALSE,"No se pudo eliminar el registro",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }

    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    protected static function SP_Listar($Entidad){
        $query = "EXEC ".$Entidad."_LISTAR";
        try{
            $conexion = Self::Conexion();
            $sentencia = $conexion->prepare($query);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

 }