<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Db/Db.php';
class Ciudades extends Db{
    private $Entidad = "CIUDADES";    

    public function Leer($id){
        $Datos = Db::SP_Leer($this->Entidad,$id);
        return $Datos;
    }

    public function Crear($informacion){
        $Datos = Db::SP_Crear($this->Entidad,$informacion);
        return $Datos;
    }

    public function Actualizar($informacion){
        $Datos = Db::SP_Actualizar($this->Entidad,$informacion);
        return $Datos;
    }

    public function Eliminar($id){
        $Datos = Db::SP_Eliminar($this->Entidad,$id);
        return $Datos;
    }

    public static function GetCiudades(){
        $query = "SELECT * FROM Ciudades";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }

}
