<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Db/Db.php';
class Clientes extends Db{
    
    private $Entidad = "CLIENTES";    

    //--------------------------------------------------------------------------------//
    public function Leer($id){
        $Datos = Db::SP_Leer($this->Entidad,$id);
        return $Datos;
    }

    public function Crear($informacion){
        $Datos = Db::SP_Crear($this->Entidad,$informacion);
        return $Datos;
    }

    public function Actualizar($informacion){
        $Datos = Db::SP_Actualizar($this->Entidad,$informacion);
        return $Datos;
    }

    public function Eliminar($id){
        $Datos = Db::SP_Eliminar($this->Entidad,$id);
        return $Datos;
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    public function GetOrdenes($usuario){
        $query = "EXEC CLIENTE_LEER_ORDENES ?";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$usuario);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    public static function GetTipoClientes(){
        $query = "SELECT * FROM TipoClientes";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    public static function GetCiudades(){
        $query = "SELECT * FROM Ciudades";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    public static function GetFormaPagos(){
        $query = "SELECT * FROM FormasPago";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al obtener los datos",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //--------------------------------------------------------------------------------//

}
