<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Db/Db.php';
class Usuario extends Db{
    private $Entidad = "USUARIO";    

    public  function Leer($id){
        $Datos = Db::SP_Leer($this->Entidad,$id);
        return $Datos;
    }

    public  function Crear($informacion){
        $Datos = Db::SP_Crear($this->Entidad,$informacion);
        return $Datos;
    }

    public  function Actualizar($informacion){
        $Datos = Db::SP_Actualizar($this->Entidad,$informacion);
        return $Datos;
    }

    public  function Eliminar($id){
        $Datos = Db::SP_Eliminar($this->Entidad,$id);
        return $Datos;
    }

    //Funciones propias de usaurio
    //---------------------------------------------------------------------------------------//
    public static function ValidarUsuario($usuario,$clave){
        $query = "EXEC USUARIO_VALIDAR_CLAVE ?,?";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$usuario);
            $sentencia->bindParam(2,$clave);

            if($sentencia->execute()){
                return [TRUE,"Consulta ejecutada",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al ejecutar la consulta",$sentencia->errorCode()];
            }
            
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    public static function LeerPermisos($usuario){
        $query = "EXEC USUARIO_LEER_PERMISOS ?";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$usuario);            

            if($sentencia->execute()){
                return [TRUE,"Consulta ejecutada",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al ejecutar la consulta",$sentencia->errorCode()];
            }
            
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    public static function getIdEmpleado($usuario){
        $query = "select U.Usuario,U.ID_Empleado,C.* from Usuarios U 
            inner join UsuarioCliente UC on U.ID_Usuario = UC.ID_Usuario
            inner join Clientes C on UC.ID_Cliente = C.ID_Cliente
            where Usuario = ?";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$usuario);            

            if($sentencia->execute()){
                return [TRUE,"Consulta ejecutada",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"Error al ejecutar la consulta",$sentencia->errorCode()];
            }
            
        }catch(PDOException $e){
            return [FALSE,"Error en el programa",$e->getMessage()];
        }
    }
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    public static function RegistroCliente($Datos){
        $Datos = Db::SP_Crear("CLIENTES",$Datos);
        return $Datos;
    }
    //---------------------------------------------------------------------------------------//

    //---------------------------------------------------------------------------------------//
    public static function CrearUsuarioCliente($usuario){
        $query = "INSERT INTO UsuarioCliente
        values(
        (SELECT ID_Cliente FROM Clientes WHERE CorreoElectronico = ?),
        (SELECT ID_Usuario FROM Usuarios WHERE Usuario = ?))";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$usuario);
            $sentencia->bindParam(2,$usuario);
            if($sentencia->execute()){
                return [TRUE,"Relacion creada con exito",null];
            }else{
                return [FALSE,"No se pudo establecer la relacion usuario cliente",$sentencia->errorCode()];
            }
        }catch(PDOException $e){
            return [FALSE,"Error en el sistema",$e->getMessage()];
        }
    }
    //---------------------------------------------------------------------------------------//


}
