<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Db/Db.php';
class Productos extends Db{
    private $Entidad = "ORDENES";    

    public function Leer($id){
        $Datos = Db::SP_Leer($this->Entidad,$id);
        return $Datos;
    }

    public function Crear($informacion){
        $Datos = Db::SP_Crear($this->Entidad,$informacion);
        return $Datos;
    }

    public function Actualizar($informacion){
        $Datos = Db::SP_Actualizar($this->Entidad,$informacion);
        return $Datos;
    }

    public function Eliminar($id){
        $Datos = Db::SP_Eliminar($this->Entidad,$id);
        return $Datos;
    }

    public function Listar(){
        $Datos = Db::SP_Listar($this->Entidad);
        return $Datos;
    }

}