<?php
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Models/Productos.php';
class ProductosController extends Productos{
    private $Entidad = "PRODUCTOS";    

    public function Leer($id){
        $Datos = Db::SP_Leer($this->Entidad,$id);
        return $Datos;
    }

    public function Crear($informacion){
        $Datos = Db::SP_Crear($this->Entidad,$informacion);
        return $Datos;
    }

    public function Actualizar($informacion){
        $Datos = Db::SP_Actualizar($this->Entidad,$informacion);
        return $Datos;
    }

    public function Eliminar($id){
        $Datos = Db::SP_Eliminar($this->Entidad,$id);
        return $Datos;
    }

    public function GetProductosByCategoria($id_categoria){
        $query = "SELECT * FROM Productos WHERE id_categoria = ?";
        try{
            $conexion = Db::Conexion();
            $sentencia = $conexion->prepare($query);
            $sentencia->bindParam(1,$id_categoria);
            if($sentencia->execute()){
                return [TRUE,"Datos obtenidos con exito",$sentencia->fetchAll(PDO::FETCH_ASSOC)];
            }else{
                return [FALSE,"No se pudo obtener los datos",$sentencia->errorCode()];
            }

        }catch(PDOException $e){
            return [FALSE,"Error al obtener los datos",$e->getMessage()];
        }

    }

}


//------------------------------------------------------------------------------------//
//Control de peticiones HTTP
header('Content-Type: application/json');
if(isset($_POST)){
    $response = [
        "status"=>"fail",
        "message"=>null,
        "data"=>null
    ];

    if(isset($_POST['request'])){
        
        $ProductosController = new ProductosController;

        extract($_POST);
        switch($request){
            case 'GetProductosByCategoria':
                $Data = $ProductosController->GetProductosByCategoria($categoria);
                if($Data[0] == TRUE){                    
                    $response['status']="success";                    
                }else{
                    $response['status']="fail";                    
                }
                $response['message']=$Data[1];
                $response['data']=$Data[2];

                echo json_encode($response);
            break;
            default:
                $response['status']="fail";
                $response['message']="No hay una peticion valida";    
                echo json_encode($response);
            break;
        }
    }else{
        $response['status']="fail";
        $response['message']="No hay una peticion valida";
        echo json_encode($response);
    }

}

?>