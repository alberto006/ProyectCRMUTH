<?php
session_start();
include $_SERVER['DOCUMENT_ROOT'].'/Diamond/backend/Models/Usuario.php';
class SessionController extends Usuario{
    
    //--------------------------------------------------------------------------------//
    //Validar una si existe una sesion activa para un usuario
    public function ValidateSession(){
        if(isset($_SESSION['usuario'])){
            return TRUE;
        }else{
            return FALSE;
        }
    }
    //--------------------------------------------------------------------------------//


    //--------------------------------------------------------------------------------//
    public function InitSession($usuario,$clave){
        $ValidarUsuario = Usuario::ValidarUsuario($usuario,$clave);
        if($ValidarUsuario[2][0]['ESTATUS'] == 1){

            $permisos = Usuario::LeerPermisos($usuario);            
            $_SESSION['permisos'] = $permisos[2][0];
            $_SESSION['usuario'] = $usuario;


            //validar si es empleado o cliente
            $UsuarioID = Usuario::GetIdEmpleado($usuario);
            $tipoUsuario = (is_numeric($UsuarioID[2][0]['ID_Empleado'])) ? "Empleado" : "Cliente";
            $_SESSION['TipoUsuario'] = $tipoUsuario;
            $_SESSION['InfoCliente'] = $UsuarioID[2][0];

            return [TRUE,"Usuario Valido",$ValidarUsuario[2],["TipoUsuario" =>$tipoUsuario]];
        }else{
            return [FALSE,"Usuario Invalido",$ValidarUsuario[2],null];
        }

    }
    //--------------------------------------------------------------------------------//

    //--------------------------------------------------------------------------------//
    public function DestroySession(){
        session_destroy();
        return [TRUE,"sesion finalizada",null];
    }
    //--------------------------------------------------------------------------------//


    //--------------------------------------------------------------------------------//
    public function SetRegistroCliente($ID_TipoCliente,
                                        $NombreCliente,
                                        $RTN,
                                        $TelefonoContacto,
                                        $CorreoElectronico,
                                        $Direccion,
                                        $ID_Ciudad,
                                        $clave)
    {
        $DataCliente = array(
            $ID_TipoCliente,
            $NombreCliente,
            $RTN,
            $TelefonoContacto,
            $CorreoElectronico,
            $Direccion,
            $ID_Ciudad,
            null
        );

        $DatosCliente = Usuario::RegistroCliente($DataCliente);
        
        if($DatosCliente[0] == TRUE){
            $DataUsuario = array(
                null,
                '3',
                '1',
                $CorreoElectronico,
                $clave
            );
            $DatosUsuario = Usuario::Crear($DataUsuario);

            if($DatosUsuario[0] == TRUE){

                $Relacion = Usuario::CrearUsuarioCliente($CorreoElectronico);

                if($Relacion[0] == TRUE){
                    return [TRUE,"Registro Completado",[$DatosCliente,$DatosUsuario]];
                }else{
                    return [FALSE,"No se pudo crear la relacion usuario => cliente",$DatosUsuario];    
                }
                
            }else{
                return [FALSE,"No se pudo crear el usuario en el sistema",$DatosUsuario];
            }

        }else{
            return [FALSE,"No se pudo crear el cliente en el sistema",$DatosCliente];
        }

    }

    //--------------------------------------------------------------------------------//

}

//------------------------------------------------------------------------------------//
//Control de peticiones HTTP
header('Content-Type: application/json');
if(isset($_POST)){
    $response = [
        "status"=>"fail",
        "message"=>null,
        "data"=>null
    ];

    if(isset($_POST['request'])){
        
        $SessionController = new SessionController;

        extract($_POST);
        switch($request){
            case 'InitSession':
                $Data = $SessionController->InitSession($usuario,$clave);
                if($Data[0] == TRUE){                    
                    $response['status']="success";                    
                }else{
                    $response['status']="fail";                    
                }
                $response['message']=$Data[1];
                $response['data']=$Data[3];

                echo json_encode($response);
            break;
            case 'DestroySession':
                $Data = $SessionController->DestroySession();
                if($Data[0] == TRUE){                    
                    $response['status']="success";                    
                }else{
                    $response['status']="fail";                    
                }
                $response['message']=$Data[1];                

                echo json_encode($response);
            break;
            case 'RegistroCliente':
                $Data = $SessionController->SetRegistroCliente($ID_TipoCliente,$NombreCliente,$RTN,$TelefonoContacto,$CorreoElectronico,$Direccion,$ID_Ciudad,$clave);
                if($Data[0]==TRUE){
                    $sesion = $SessionController->InitSession($CorreoElectronico,$clave);
                    if($Data[0] == TRUE){                    
                        $response['status']="success";                    
                    }else{
                        $response['status']="fail";                    
                    }
                    $response['message']=$Data[1];
                    $response['data']=$Data;
    
                    echo json_encode($response);
                }else{
                    $response['status']="fail"; 
                    $response['message']=$Data[1];
                    
    
                    echo json_encode($response);
                }

            break;
            default:
                $response['status']="fail";
                $response['message']="No hay una peticion valida";    
                echo json_encode($response);
            break;
        }
    }else{
        $response['status']="fail";
        $response['message']="No hay una peticion valida";
        echo json_encode($response);
    }

}